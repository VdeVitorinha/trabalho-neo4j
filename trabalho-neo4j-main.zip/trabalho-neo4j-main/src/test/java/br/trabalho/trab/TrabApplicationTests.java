package br.trabalho.trab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabApplicationTests {

	@Test
	void contextLoads() {
	}

}
